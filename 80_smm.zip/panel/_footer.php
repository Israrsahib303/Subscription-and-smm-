</div> </main> </div> <footer class="admin-footer">
        <p>&copy; <?php echo date('Y'); ?> <?php echo $GLOBALS['settings']['site_name'] ?? 'SubHub v6.3'; ?>. All rights reserved.</p>
    </footer>
    
    </body>
</html>