<?php
// This file is included at the top of all admin pages
require_once __DIR__ . '/../includes/helpers.php';
requireAdmin(); // This checks if user is logged in AND is_admin == 1
?>