</div> <script src="../assets/js/countdown.js?v=2.2"></script>
    <script src="../assets/js/main.js?v=2.2"></script>
</body>
</html>