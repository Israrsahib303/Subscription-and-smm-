<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'israrlia_test');
define('DB_NAME', 'israrlia_test');
define('DB_PASS', 'israrlia_test');
define('SITE_URL', 'https://test.israrliaqat.shop');

// Timezone
date_default_timezone_set('Asia/Karachi');
